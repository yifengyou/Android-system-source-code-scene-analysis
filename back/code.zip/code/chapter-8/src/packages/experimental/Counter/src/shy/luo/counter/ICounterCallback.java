package shy.luo.counter;

public interface ICounterCallback {
	void count(int val);
}
